create view all_items_ids(item, type, itemtype, color, shirtsize, picturesize, price) as
SELECT items.id        AS item,
       type.id         AS type,
       item_type.id    AS itemtype,
       color.id        AS color,
       s.id            AS shirtsize,
       picture_size.id AS picturesize,
       items.id        AS price
FROM ((((((((((items
    FULL JOIN item_type_relation itr ON ((items.id = itr.item_id)))
    FULL JOIN type ON ((type.id = itr.type_id)))
    FULL JOIN item_item_type_relation iitr ON ((items.id = iitr.item_id)))
    FULL JOIN item_type ON ((item_type.id = iitr.item_type_id)))
    FULL JOIN color_item_relation cir ON ((items.id = cir.item_id)))
    FULL JOIN color ON ((cir.color_id = color.id)))
    FULL JOIN item_picture_size_relation ipsr ON ((items.id = ipsr.item_id)))
    FULL JOIN picture_size ON ((picture_size.id = ipsr.picture_size_id)))
    FULL JOIN item_size_relation isr ON ((items.id = isr.item_id)))
         FULL JOIN size s ON ((isr.size_id = s.id)));

alter table all_items_ids
    owner to postgres;

